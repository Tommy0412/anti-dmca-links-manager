<?php
include("url.php");
session_start();
session_regenerate_id(true);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Login</title>
    <link rel="icon" type="image/x-icon" href="<?=$url?>/favicon.ico">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.2.19/tailwind.min.css">
</head>
<body class="bg-gray-100">

<?php
require('db.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['username'])) {
    $username = mysqli_real_escape_string($con, stripslashes($_POST['username']));
    $password = stripslashes($_POST['password']);
    
    $site_salt = "antidmcalinksdmanager";
    $salted_hash = hash('sha256', $password . $site_salt);

    $sql = "SELECT username, password FROM users WHERE username = ? AND password = ?";
    $stmt = $con->prepare($sql);
    $stmt->bind_param('ss', $username, $salted_hash);

    if ($stmt->execute()) {
        $result = $stmt->get_result();
        if ($result->num_rows > 0) {
            $_SESSION['username'] = $username;
            header("Location: $url/index.php");
            exit();
        } else {
            $error_message = "Username/password is incorrect.";
        }
    } else {
        $error_message = "An error occurred. Please try again.";
    }

    $stmt->close();
    $con->close();
} else {
    $error_message = null;
}
?>

<div class="flex items-center justify-center min-h-screen">
    <div class="bg-white p-8 rounded shadow-md w-96">
        <h1 class="text-2xl font-bold mb-6 text-center">Log In</h1>

        <?php if ($error_message): ?>
            <div class="bg-red-100 text-red-700 p-4 mb-4 rounded">
                <?= htmlentities($error_message, ENT_QUOTES | ENT_HTML5, 'UTF-8') ?>
            </div>
        <?php endif; ?>

        <form action="<?= htmlspecialchars($_SERVER["PHP_SELF"]) ?>" method="post" name="login" class="space-y-4">
            <div>
                <label for="username" class="block text-sm font-medium text-gray-700">Username</label>
                <input type="text" name="username" id="username" placeholder="Username" required class="w-full p-2 border rounded">
            </div>
            <div>
                <label for="password" class="block text-sm font-medium text-gray-700">Password</label>
                <input type="password" name="password" id="password" placeholder="Password" required class="w-full p-2 border rounded">
            </div>
            <div>
                <button type="submit" name="submit" class="w-full bg-blue-500 text-white p-2 rounded hover:bg-blue-600">Login</button>
            </div>
        </form>
        
        <p class="mt-4 text-center text-gray-600">
            Not registered yet? <a href="<?= $url ?>/registration.php" class="text-blue-500 hover:underline">Register Here</a>
        </p>
    </div>
</div>

</body>
</html>