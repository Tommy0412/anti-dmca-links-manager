<?php
require_once 'auth.php';
require_once 'db.php';
include("url.php");

$results_per_page = 15;
$current_page = isset($_GET['page']) ? $_GET['page'] : 1;

$search_query = isset($_GET['search']) ? $_GET['search'] : '';
$search_condition = '';
if (!empty($search_query)) {
    $search_condition = "WHERE id LIKE '%$search_query%' OR filemoon LIKE '%$search_query%' OR filemoon_backup LIKE '%$search_query%'";
}

$sql_count = "SELECT COUNT(*) AS total FROM links $search_condition";
$result_count = $con->query($sql_count);
$row_count = $result_count->fetch_assoc();
$total_records = $row_count['total'];
$total_pages = ceil($total_records / $results_per_page);
$offset = ($current_page - 1) * $results_per_page;
$sql = "SELECT * FROM links $search_condition LIMIT $offset, $results_per_page";
$result = $con->query($sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Links</title>
	<link rel="icon" type="image/x-icon" href="favicon.ico">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script>
        function toggle(source) {
            checkboxes = document.getElementsByName('selected_ids[]');
            for (var i = 0, n = checkboxes.length; i < n; i++) {
                checkboxes[i].checked = source.checked;
            }
        }
    </script>
</head>
<body>
<nav class="navbar navbar-expand-md bg-dark navbar-dark">
    <a class="navbar-brand" href="#">Links</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="collapsibleNavbar">
      <ul class="navbar-nav">
        <li class="nav-item">
          <a class="nav-link" href="index.php">Home</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="add.php">Add New</a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="logout.php">Logout</a>
        </li>
      </ul>
    </div>
  </nav>
<div class="container mt-5">
    <h2 class="mb-4">Links</h2>
    <form class="form-inline mb-3" action="" method="GET">
        <div class="form-group mr-2">
            <input type="text" class="form-control" name="search" placeholder="Search" value="<?php echo htmlspecialchars($search_query); ?>">
        </div>
        <button type="submit" class="btn btn-primary mr-2">Search</button>
        <a href="?" class="btn btn-secondary">Reset</a>
    </form>

    <form action="bulk_delete.php" method="POST" onsubmit="return confirm('Are you sure you want to delete the selected items?');">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th><input type="checkbox" onclick="toggle(this);"></th>
                    <th>ID</th>
					<th>Title</th>
                    <th>filemoon</th>
					<th>filemoon_backup</th>
					<th>Embed url</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
            <?php
            while ($row = $result->fetch_assoc()) {
				$id = $row['id'];
				$title = $row['title'];
	            $filemoon = $row['filemoon'];
                $filemoon_backup = $row['filemoon_backup'];
				$embed_url = "$url/embed.php?id=$id";
	 
                echo "<tr>
                        <td><input type='checkbox' name='selected_ids[]' value='{$id}'></td>
                        <td>{$id}</td>
						<td>{$title}</td>
                        <td>{$filemoon}</td>
						<td>{$filemoon_backup}</td>
						<td>{$embed_url}</td>
                        <td>
                            <a href='edit.php?id={$id}' class='btn btn-sm btn-warning'>Edit</a> 
                            <a href='delete.php?id={$id}' class='btn btn-sm btn-danger' onclick='return confirm(\"Are you sure you want to delete this item?\")'>Delete</a>
                        </td>
                      </tr>";
            }
            ?>
            </tbody>
        </table>
        <button type="submit" class="btn btn-danger">Delete Selected</button>
    </form>

    <nav class="mt-3">
        <ul class="pagination justify-content-center">
            <?php
            $range = 5; 
            $start = ($current_page - $range > 0) ? $current_page - $range : 1;
            $end = ($current_page + $range < $total_pages) ? $current_page + $range : $total_pages;

            if ($current_page > 1) {
                echo "<li class='page-item'><a class='page-link' href='?page=1'>First</a></li>";
                echo "<li class='page-item'><a class='page-link' href='?page=".($current_page - 1)."'>Previous</a></li>";
            }

            for ($i = $start; $i <= $end; $i++) {
                $active_class = ($current_page == $i) ? "active" : "";
                echo "<li class='page-item $active_class'><a class='page-link' href='?page=".$i."'>".$i."</a></li>";
            }

            if ($current_page < $total_pages) {
                echo "<li class='page-item'><a class='page-link' href='?page=".($current_page + 1)."'>Next</a></li>";
                echo "<li class='page-item'><a class='page-link' href='?page=".$total_pages."'>Last</a></li>";
            }
            ?>
        </ul>
    </nav>
</div>

<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</body>
</html>

<?php
$con->close();
?>