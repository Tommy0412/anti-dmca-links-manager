<?php
//ENTER WEBSITE URL BELLOW (without / at the end)
//example: https://website.com/script
$url = "";