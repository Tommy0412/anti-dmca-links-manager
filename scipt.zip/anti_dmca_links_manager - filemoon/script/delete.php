<?php
/**
 * @author Tommy0412
 **/
 
include("auth.php");
require('db.php');
if(isset($_REQUEST['id'])){
$id=$_REQUEST['id'];	
$sql = $con->prepare("DELETE FROM links WHERE id=?");
$sql->bind_param('s', $id);
$sql->execute();
if ($sql->execute()) {
echo "<script>window.alert('DELETED');window.location.href='view.php';</script>";
} else {
    echo "Failed to delete";
}

$sql->close();
$con->close();
 }
?>