<?php
if ($_SERVER["HTTP_SEC_FETCH_SITE"] != "same-origin") {
    die('<center><p style="color:#FFFF00;">Access denied!</p></center>');
} else {
    $url = isset($_GET["url"]) ? $_GET["url"] : '';
    if (empty($url)) {
        die('<center><p style="color:#FFFF00;">URL parameter is missing!</p></center>');
    }
    $decodedUrl = base64_decode($url);
    if ($decodedUrl === false) {
        die('<center><p style="color:#FFFF00;">Failed to decode URL!</p></center>');
    }
    header("Location: $decodedUrl", true, 301);
    exit();
}
?>