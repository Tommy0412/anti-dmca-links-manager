<?php
/**
 * @author Tommy0412
 **/
 
include("auth.php");
require('db.php');
include("url.php");
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="icon" type="image/x-icon" href="<?=$url?>/favicon.ico">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.2.19/tailwind.min.css" rel="stylesheet">
    <style>
        .submenu {
            display: none;
        }
        .submenu.show {
            display: block;
        }
    </style>
</head>
<body class="bg-gray-200 h-screen flex flex-col sm:flex-row">
    <!-- Mobile Navbar -->
    <div class="bg-black p-4 sm:hidden flex justify-between items-center">
        <h1 class="text-xl font-bold text-yellow-400">Menu</h1>
        <button id="burgerMenu" class="text-yellow-400 focus:outline-none">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16m-7 6h7"></path>
            </svg>
        </button>
    </div>

    <!-- Sidebar Menu -->
    <div id="sidebar" class="w-full sm:w-64 bg-black shadow-md p-4 hidden sm:block">
        <h1 class="text-xl font-bold text-yellow-400 mb-4 sm:block hidden">Menu</h1>
        <ul class="space-y-2">
            <li>
                <button onclick="toggleSubmenu('submenu-1')" class="w-full text-left py-2 px-4 text-yellow-400 hover:bg-gray-800 focus:bg-gray-700">
                    Links
                </button>
                <ul id="submenu-1" class="submenu pl-4 space-y-1 sm:pl-6">
                    <li>
                        <a href="<?=$url?>/add.php" class="block py-2 px-4 text-yellow-300 hover:bg-gray-800 focus:bg-gray-700">Add New Link</a>
                    </li>
                    <li>
                        <a href="<?=$url?>/view.php" class="block py-2 px-4 text-yellow-300 hover:bg-gray-800 focus:bg-gray-700">View Links</a>
                    </li>
                </ul>
            </li>
            <li>
                <a href="<?=$url?>/backup.php" class="block py-2 px-4 text-yellow-400 hover:bg-gray-800 focus:bg-gray-700">Backup</a>
            </li>
            <li>
                <a href="<?=$url?>/logout.php" class="block py-2 px-4 text-yellow-400 hover:bg-gray-800 focus:bg-gray-700">Logout</a>
            </li>
        </ul>
    </div>

    <!-- Main Content Area -->
    <div class="flex-1 p-4 bg-white">
        <h2 class="text-2xl font-bold mb-4 text-black">Welcome <?php echo $_SESSION['username']; ?>!</h2>
        <p class="text-gray-700"></p>
    </div>

    <script>
        function toggleSubmenu(id) {
            const submenu = document.getElementById(id);
            submenu.classList.toggle('show');
        }

        const burgerMenu = document.getElementById('burgerMenu');
        const sidebar = document.getElementById('sidebar');
        burgerMenu.addEventListener('click', () => {
            sidebar.classList.toggle('hidden');
        });
    </script>
</body>
</html>