<?php
/**
 * @author Tommy0412
 **/
 
require_once 'auth.php';
require_once 'db.php';

if (isset($_POST['selected_ids'])) {
    $selected_ids = $_POST['selected_ids'];
    $id_list = implode(",", $selected_ids);

    $sql = "DELETE FROM links WHERE id IN ($id_list)";

    if ($con->query($sql) === TRUE) {
        echo "Records deleted successfully";
    } else {
        echo "Error deleting records: " . $con->error;
    }
} else {
    echo "No records selected";
}

$con->close();

header("Location: view.php");
exit();
?>