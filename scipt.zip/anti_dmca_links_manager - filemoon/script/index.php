<?php
/**
 * @author Tommy0412
 **/ 
 
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
//error_reporting(E_ALL);

include("auth.php");
include("db.php");
include("url.php");

$links_count_sql = "SELECT COUNT(*) as links_count FROM links";
$links_count_result = $con->query($links_count_sql);

if ($links_count_result->num_rows > 0) {
    $links_count_row = $links_count_result->fetch_assoc();
    $links_count = $links_count_row['links_count'];
} else {
    $links_count = 0;
}

$con->close();
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="icon" type="image/x-icon" href="<?=$url?>/favicon.ico">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.2.19/tailwind.min.css" rel="stylesheet">
    <style>
        .submenu {
            display: none;
        }

        .submenu.show {
            display: block;
        }
    </style>
</head>

<body class="bg-gray-200 h-screen flex flex-col sm:flex-row">
    <!-- Mobile Navbar -->
    <div class="bg-black p-4 sm:hidden flex justify-between items-center">
        <h1 class="text-xl font-bold text-yellow-400">Menu</h1>
        <button id="burgerMenu" class="text-yellow-400 focus:outline-none">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16m-7 6h7"></path>
            </svg>
        </button>
    </div>

    <!-- Sidebar -->
    <div id="sidebar" class="sidebar w-full sm:w-64 bg-black shadow-md p-4 hidden sm:block">
        <h1 class="text-xl font-bold text-yellow-400 mb-4 sm:block hidden">Menu</h1>
        <ul>
            <li>
                <a href="<?=$url?>/index.php" class="block py-2 px-4 text-yellow-400 hover:bg-gray-800 focus:bg-gray-700">Home</a>
            </li>
            <li>
                <a href="<?=$url?>/dashboard.php" class="block py-2 px-4 text-yellow-400 hover:bg-gray-800 focus:bg-gray-700">Dashboard</a>
            </li>
            <li>
                <a href="<?=$url?>/logout.php" class="block py-2 px-4 text-yellow-400 hover:bg-gray-800 focus:bg-gray-700">Logout</a>
            </li>
        </ul>
    </div>

    <!-- Content Area -->
    <div class="flex-1 p-4 bg-white">
        <h2 class="text-2xl font-bold mb-4 text-black">Welcome <?php echo $_SESSION['username']; ?>!</h2>
        <p class="text-gray-700">Number of Links: <?php echo $links_count; ?></p>
    </div>

    <script>
        const burgerMenu = document.getElementById('burgerMenu');
        const sidebar = document.getElementById('sidebar');
        burgerMenu.addEventListener('click', () => {
            sidebar.classList.toggle('hidden');
        });

        function toggleSubmenu(id) {
            const submenu = document.getElementById(id);
            submenu.classList.toggle('show');
        }
    </script>
</body>

</html>