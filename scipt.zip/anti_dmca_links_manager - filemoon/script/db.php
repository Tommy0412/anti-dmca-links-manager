<?php
/**
 * @author Tommy0412
 **/
 
// Db config
define('HOST', 'localhost');
define('PORT', 3306);
define('DATABASE', '');
define('USERNAME', '');
define('PASSWORD', '');

//error_reporting(E_ALL);
//ini_set('display_errors', 1);

$mysqliDriver = new mysqli_driver();
$mysqliDriver->report_mode = (MYSQLI_REPORT_ERROR | MYSQLI_REPORT_STRICT);

$con = new mysqli(HOST, USERNAME, PASSWORD, DATABASE, PORT);

$con->set_charset('utf8mb4');