<?php
/**
 * @author Tommy0412
 **/
 
session_start();

if (!isset($_SESSION["regenerated"])) {
    session_regenerate_id(true);
    $_SESSION["regenerated"] = true;
}

if (!isset($_SESSION["username"])) {
    header("Location: login.php");
    exit();
}
?>