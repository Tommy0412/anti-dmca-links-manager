<?php
include("url.php");
require('db.php');

session_start();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['username'], $_POST['email'], $_POST['password'])) {
    $username = stripslashes($_POST['username']);
    $username = mysqli_real_escape_string($con, $username);

    $email = stripslashes($_POST['email']);
    $email = mysqli_real_escape_string($con, $email);

    $password = stripslashes($_POST['password']);
    $password = mysqli_real_escape_string($con, $password);

    $site_salt = "antidmcalinksdmanager";
    $salted_hash = hash('sha256', $password . $site_salt);

    $api_key = bin2hex(random_bytes(16));
    $trn_date = date("Y-m-d H:i:s");

    $sql = "INSERT INTO users (username, password, api_key, email, trn_date) VALUES (?, ?, ?, ?, ?)";
    if ($stmt = $con->prepare($sql)) {
        $stmt->bind_param('sssss', $username, $salted_hash, $api_key, $email, $trn_date);
        if ($stmt->execute()) {
            $success_message = "You are registered successfully. Click here to <a href='$url/login.php' class='text-blue-500 underline'>Login</a>.";
        } else {
            $error_message = "Registration failed. Please try again.";
        }
        $stmt->close();
    } else {
        $error_message = "Failed to prepare the SQL statement.";
    }
    $con->close();
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Registration</title>
    <link rel="icon" type="image/x-icon" href="<?=$url?>/favicon.ico">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.2.19/tailwind.min.css" rel="stylesheet">
</head>
<body class="bg-gray-100 flex items-center justify-center min-h-screen">
    <div class="bg-white p-8 rounded shadow-md w-full max-w-md">
        <h1 class="text-2xl font-bold mb-6 text-center">Registration</h1>

        <?php if (!empty($success_message)): ?>
            <div class="bg-green-100 text-green-700 p-4 mb-4 rounded">
                <?= $success_message ?>
            </div>
        <?php elseif (!empty($error_message)): ?>
            <div class="bg-red-100 text-red-700 p-4 mb-4 rounded">
                <?= $error_message ?>
            </div>
        <?php endif; ?>

        <form action="<?= htmlspecialchars($_SERVER["PHP_SELF"]) ?>" method="post" class="space-y-4">
            <div>
                <label for="username" class="block text-sm font-medium text-gray-700">Username</label>
                <input type="text" name="username" id="username" placeholder="Username" required class="w-full p-2 border rounded">
            </div>
            <div>
                <label for="email" class="block text-sm font-medium text-gray-700">Email</label>
                <input type="email" name="email" id="email" placeholder="Email" required class="w-full p-2 border rounded">
            </div>
            <div>
                <label for="password" class="block text-sm font-medium text-gray-700">Password</label>
                <input type="password" name="password" id="password" placeholder="Password" required class="w-full p-2 border rounded">
            </div>
            <button type="submit" name="submit" class="w-full bg-blue-500 text-white p-2 rounded hover:bg-blue-600">Register</button>
        </form>
    </div>
</body>
</html>