<?php
/**
 * @author Tommy0412
 **/
 
//API Key & email https://mixdrop.ag/api
$mixdrop_email = "";
$mixdrop_api = "";
?>