<?php
/**
 * Tommy0412
 */

//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
//error_reporting(E_ALL);

require_once 'db.php';
require_once 'url.php';
require_once 'apis.php';

function getRequestParam($param) {
    return isset($_GET[$param]) ? htmlspecialchars(trim($_GET[$param]), ENT_QUOTES, 'UTF-8') : null;
}

$id = getRequestParam('id');

if (!$id) {
    http_response_code(400); 
    die(json_encode(['error' => 'ID is required']));
}

$sql = 'SELECT id, mixdrop, mixdrop_backup FROM links WHERE id = ?';
$statement = $con->prepare($sql);
if (!$statement) {
    error_log("Database prepare failed: " . $con->error);
    die(json_encode(['error' => 'Database error']));
}
$statement->bind_param('s', $id);
$statement->execute();
$result = $statement->get_result();

if ($result->num_rows === 0) {
    http_response_code(404); 
    die(json_encode(['error' => 'Not found']));
}

$row = $result->fetch_assoc();
$mixdrop = $row['mixdrop'];
$mixdrop_backup = $row['mixdrop_backup'];
$mixdropurl = "https://mixdrop.ag/e/$mixdrop";   
$b64link = !empty($mixdropurl) ? base64_encode($mixdropurl) : '';
$fullUrl = $url . "/get.php?url=" . $b64link;

function fetchApiData($url) {
    $response = file_get_contents($url);
    if ($response === false) {
        error_log("Failed to fetch data from $url");
        return null;
    }
    return json_decode($response, true);
}

function clonemixdropFile($apiKey, $mixdrop_email, $fileCode) {
    $clone_url = "https://api.mixdrop.ag/fileduplicate?email=$mixdrop_email&key=$apiKey&ref=$fileCode";
    return fetchApiData($clone_url);
}

function updateDatabase($con, $column, $value, $id) {
    $stmt = $con->prepare("UPDATE links SET $column = ? WHERE id = ?");
    $stmt->bind_param('ss', $value, $id);
    $stmt->execute();
    $stmt->close();
}

if (empty($mixdrop_backup) && !empty($mixdrop)) {
    $clone_obj = clonemixdropFile($mixdrop_api, $mixdrop_email, $mixdrop);
    if ($clone_obj['success'] === true) {
        $mixdrop2 = $clone_obj['result']['fileref'];
        updateDatabase($con, 'mixdrop_backup', $mixdrop2, $id);
    }
}

$timecheckDir = __DIR__ . '/timecheck';
$jsonFileName = $timecheckDir . "/timecheck_$id.json"; 
$currentTime = time();

if (!is_dir($timecheckDir)) {
    mkdir($timecheckDir, 0755, true); 
}

if (!file_exists($jsonFileName)) {
    $data = [
        'last_checked_time' => $currentTime
    ];
    file_put_contents($jsonFileName, json_encode($data));
} else {
    $fileContent = file_get_contents($jsonFileName);
    $data = json_decode($fileContent, true);
    $lastCheckedTime = $data['last_checked_time'];
    $timeDifference = $currentTime - $lastCheckedTime;

    if ($timeDifference >= 21600) { 

if (!empty($mixdrop)) {
    $mixdrop_api_check_url = "https://api.mixdrop.ag/fileinfo2?email=$mixdrop_email&key=$mixdrop_api&ref[]=$mixdrop";
    $mixdropobj_check = fetchApiData($mixdrop_api_check_url);

    if ($mixdropobj_check['success'] === true) {
		foreach ($mixdropobj_check['result'] as $fileRef => $fileData) {
			if ($fileData['status'] === 'notfound' && !empty($mixdrop_backup)) {	
                $clone_obj = clonemixdropFile($mixdrop_api, $mixdrop_email, $mixdrop_backup);
                if ($clone_obj['success'] === true) {
                    $mixdrop2 = $clone_obj['result']['fileref'];
                    updateDatabase($con, 'mixdrop', $mixdrop2, $id);
					header("Refresh:1");
                    exit();
                }
            }
        }
    }
}

if (!empty($mixdrop_backup)) {
    $mixdrop_backup_check_url = "https://api.mixdrop.ag/fileinfo2?email=$mixdrop_email&key=$mixdrop_api&ref[]=$mixdrop_backup";
    $mixdrop_backup_obj_check = fetchApiData($mixdrop_backup_check_url);

    if ($mixdrop_backup_obj_check['success'] === true) {
		foreach ($mixdrop_backup_obj_check['result'] as $fileRef => $fileData) {
			if ($fileData['status'] === 'notfound' && !empty($mixdrop)) {
                $clone_obj = clonemixdropFile($mixdrop_api, $mixdrop_email, $mixdrop);
                if ($clone_obj['success'] === true) {
                    $mixdrop2 = $clone_obj['result']['fileref'];
                    updateDatabase($con, 'mixdrop_backup', $mixdrop2, $id);
                }
            }
        }
    }
}

        $data['last_checked_time'] = $currentTime;
        file_put_contents($jsonFileName, json_encode($data));
    }
}

$statement->close();
$con->close();

?>
<?php if (isset($id)) { ?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <META NAME="robots" content="noindex,nofollow">
    <link rel="icon" type="image/x-icon" href="<?php echo $url ?>/favicon.ico">
<style>
        body, html {
            margin: 0;
            padding: 0;
            height: 100%;
            width: 100%;
            overflow: hidden;
            font-family: Arial, sans-serif;
            position: relative;
        }
        iframe {
            position: absolute;
            top: 0;
            left: 0;
            width: 100%;
            height: 100%;
            border: none;
        }
    </style>
</head>
<body>
<iframe src="<?php echo $fullUrl ?>" referrerpolicy="origin" loading="lazy" allowfullscreen="true" webkitallowfullscreen="true" mozallowfullscreen="true"></iframe>
</body>
</html>
<?php } ?>