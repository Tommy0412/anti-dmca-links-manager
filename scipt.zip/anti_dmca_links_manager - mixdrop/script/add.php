<?php
$status = "";

include("auth.php");
include("url.php");
include("apis.php");
require('db.php');

if (isset($_POST['new']) && $_POST['new'] == 1) {
    $trn_date = date("Y-m-d H:i:s");
    $mixdrop_ids = $_REQUEST['mixdrop'];
    $mixdrop_backup = ""; 
    $submittedby = $_SESSION["username"];
    $mixdrop_ids_array = array_map('trim', explode(',', $mixdrop_ids));
    $inserted_count = 0;
	
    foreach ($mixdrop_ids_array as $mixdrop_id) {
        if (!empty($mixdrop_id)) {
            $api_url = "https://api.mixdrop.ag/fileinfo2?email=$mixdrop_email&key=$mixdrop_api&ref[]=$mixdrop_id";

            $api_response = file_get_contents($api_url);
            $api_data = json_decode($api_response, true);

            if ($api_data['success'] && isset($api_data['result'][$mixdrop_id]['title'])) {
                $title = $api_data['result'][$mixdrop_id]['title'];
            } else {
                $title = "Unknown Title";
            }

            $stmt = $con->prepare("INSERT INTO links (trn_date, submittedby, title, mixdrop, mixdrop_backup) VALUES (?, ?, ?, ?, ?)");
            $stmt->bind_param("sssss", $trn_date, $submittedby, $title, $mixdrop_id, $mixdrop_backup);

            if ($stmt->execute()) {
                $inserted_count++;
            }
        }
    }

    if ($inserted_count > 0) {
        $status = "$inserted_count mixdrop IDs added successfully.";
    } else {
        $status = "Error adding links, try again!";
    }
}
?>
<!DOCTYPE html>
<html>
<head>
<meta charset="utf-8">
<title>Add New Link</title>
<link rel="icon" type="image/x-icon" href="<?php echo $url ?>/favicon.ico">
<link href="https://cdnjs.cloudflare.com/ajax/libs/tailwindcss/2.2.19/tailwind.min.css" rel="stylesheet">
</head>
<body>
<nav class="bg-gray-800 p-4">
    <div class="container mx-auto flex items-center justify-between">
        <a class="text-white text-lg font-semibold" href="#">Add New Link</a>
        <button class="text-white md:hidden" id="nav-toggle">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16m-7 6h7"></path>
            </svg>
        </button>
        <div class="hidden w-full md:flex md:items-center md:w-auto" id="nav-content">
            <ul class="flex flex-col md:flex-row md:space-x-4">
                <li><a class="text-gray-300 hover:text-white" href="<?=$url?>/dashboard.php">Dashboard</a></li>
                <li><a class="text-gray-300 hover:text-white" href="<?=$url?>/view.php">View</a></li>
                <li><a class="text-gray-300 hover:text-white" href="<?=$url?>/logout.php">Logout</a></li>
            </ul>
        </div>
    </div>
</nav>

<div class="container mx-auto mt-10">
    <div class="max-w-md mx-auto bg-white p-8 border border-gray-300 rounded-lg shadow-md">
        <form name="form" method="post" action=""> 
            <input type="hidden" name="new" value="1" />
            <p><textarea class="w-full h-32 p-4 mb-4 border border-gray-300 rounded text-lg resize-none" name="mixdrop" placeholder="Enter MixDrop IDs (comma-separated)" required></textarea></p>
            <!--<p><input class="w-full p-2 mb-4 border border-gray-300 rounded" type="text" name="mixdrop_backup" placeholder="mixdrop_backup id (not required)"/></p>-->
            <p><input class="w-full p-2 mb-4 bg-blue-500 text-white rounded cursor-pointer hover:bg-blue-600" name="submit" type="submit" value="Submit" /></p>
        </form>
        <p class="text-red-500"><?php echo $status; ?></p>
    </div>
</div>

<script>
    document.getElementById('nav-toggle').addEventListener('click', function() {
        document.getElementById('nav-content').classList.toggle('hidden');
    });
</script>
</body>
</html>