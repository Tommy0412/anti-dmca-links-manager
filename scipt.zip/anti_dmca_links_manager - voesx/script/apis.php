<?php
/**
 * @author Tommy0412
 **/
 
//API Key https://voe.sx/settings
$voesx_api = "";
?>