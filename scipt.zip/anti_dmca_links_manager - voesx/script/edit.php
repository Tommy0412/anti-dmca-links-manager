<?php
/**
 * @author Tommy0412
 **/
 
//ini_set('display_errors', 1);
//ini_set('display_startup_errors', 1);
//error_reporting(E_ALL);

include("auth.php"); 
require('db.php');
include("url.php");
if(isset($_REQUEST['id'])) {
$id = $_REQUEST['id'];
$query="SELECT * FROM links WHERE id=?";
		$stmt=$con->prepare($query);
		$stmt->bind_param("i",$id);
		$stmt->execute();
		$result=$stmt->get_result();
		$row=$result->fetch_assoc();
}else{
die('<center><p style="color:yellow;">ID MISSING!</center></p>');
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Update</title>
    <link rel="icon" type="image/x-icon" href="<?=$url?>/favicon.ico">
    <script src="https://cdn.tailwindcss.com"></script>
</head>
<body class="bg-gray-100 font-sans leading-normal tracking-normal">

    <div class="container mx-auto p-4">
<nav class="bg-gray-800 p-4">
    <div class="container mx-auto flex items-center justify-between">
        <a class="text-white text-lg font-semibold" href="#">Update</a>
        <button class="text-white md:hidden" id="nav-toggle">
            <svg class="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M4 6h16M4 12h16m-7 6h7"></path>
            </svg>
        </button>
        <div class="hidden w-full md:flex md:items-center md:w-auto" id="nav-content">
            <ul class="flex flex-col md:flex-row md:space-x-4">
                <li><a class="text-gray-300 hover:text-white" href="<?=$url?>/dashboard.php">Dashboard</a></li>
                <li><a class="text-gray-300 hover:text-white" href="<?=$url?>/view.php">View</a></li>
                <li><a class="text-gray-300 hover:text-white" href="<?=$url?>/logout.php">Logout</a></li>
            </ul>
        </div>
    </div>
</nav>

        <div class="bg-white shadow-md rounded px-8 pt-6 pb-8 mb-4">
            <?php $status = ""; if (isset($_POST['new']) && $_POST['new'] == 1) { 
                $id = $_REQUEST['id'];
				$title = $_REQUEST['title'];
                $trn_date = date("Y-m-d H:i:s");
                $voesx = $_REQUEST['voesx']; 
				$voesx_backup = $_REQUEST['voesx_backup'];
                $submittedby = $_SESSION["username"];
                $query = "UPDATE links SET trn_date=?,submittedby=?,title=?,voesx=?,voesx_backup=? WHERE id=?";
                $stmt = $con->prepare($query);
                $stmt->bind_param("sssssi", $trn_date, $submittedby, $title, $voesx, $voesx_backup, $id);
                $stmt->execute();
                $stmt->close();
                $con->close();
                $status = "Updated Successfully</br></br><a href='$url/embed.php?id=$id'>View</a>";
                echo '<p class="text-red-500">'.$status.'</p>';
            } else { ?>

            <form name="form" method="post" action="">
                <input type="hidden" name="new" value="1" />
                <input name="id" type="hidden" value="<?php echo $row['id'];?>" />

                <div class="mb-4">
                    <input type="text" name="voesx" placeholder="voesx" value="<?php echo $row['voesx'];?>" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" />
                </div>
                <div class="mb-4">
                    <input type="text" name="voesx_backup" placeholder="voesx_backup" value="<?php echo $row['voesx_backup'];?>" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" />
                </div>
				<div class="mb-4">
                    <input type="text" name="title" placeholder="title" value="<?php echo $row['title'];?>" class="shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 leading-tight focus:outline-none focus:shadow-outline" />
                </div>

                <div class="flex items-center justify-between">
                    <button type="submit" class="bg-blue-500 hover:bg-blue-700 text-white font-bold py-2 px-4 rounded focus:outline-none focus:shadow-outline">Update</button>
                </div>
            </form>

            <?php } ?>
        </div>
    </div>

</body>
</html>